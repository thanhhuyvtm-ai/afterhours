import express from "express";
import cors from "cors";
import http from "node:http";
import { Server } from "socket.io";
import bcrypt from "bcryptjs";
import { randomBytes } from "node:crypto";

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") || "*" }));
app.use(express.json());
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CLIENT_ORIGIN?.split(",") || "*", methods: ["GET", "POST"] } });

const rooms = new Map(); // MVP: in-memory; use Redis/database for production.
const clean = (v, max=40) => String(v ?? "").trim().slice(0, max);
const roomCode = () => randomBytes(3).toString("hex").toUpperCase();

app.get("/health", (_, res) => res.json({ ok: true }));

app.post("/api/rooms", async (req, res) => {
  const name = clean(req.body.name, 24) || "Phòng bạn bè";
  const password = String(req.body.password ?? "");
  const nickname = clean(req.body.nickname, 20) || "Khách";
  if (password.length < 4 || password.length > 72) return res.status(400).json({ error: "Mật khẩu cần từ 4 đến 72 ký tự." });
  let code; do { code = roomCode(); } while (rooms.has(code));
  const passwordHash = await bcrypt.hash(password, 10);
  rooms.set(code, { code, name, passwordHash, members: new Map(), messages: [], music: { url: "", playing: false, position: 0, updatedAt: Date.now() }, game: { cards: [], turn: 0 }, ownerId: null, positions: new Map() });
  res.json({ code, name, nickname });
});

app.post("/api/rooms/:code/join", async (req, res) => {
  const room = rooms.get(clean(req.params.code, 8).toUpperCase());
  if (!room || !(await bcrypt.compare(String(req.body.password ?? ""), room.passwordHash))) {
    return res.status(401).json({ error: "Mã phòng hoặc mật khẩu không đúng." });
  }
  res.json({ code: room.code, name: room.name, nickname: clean(req.body.nickname, 20) || "Khách" });
});

io.on("connection", socket => {
  socket.on("room:enter", ({ code, nickname }) => {
    const room = rooms.get(clean(code, 8).toUpperCase());
    if (!room) return socket.emit("room:error", "Phòng không còn tồn tại. Hãy tạo phòng mới.");
    socket.join(room.code);
    socket.data.room = room.code;
    socket.data.nickname = clean(nickname, 20) || "Khách";
    room.members.set(socket.id, socket.data.nickname);
    if (!room.ownerId) room.ownerId = socket.id;
    if (!room.positions.has(socket.id)) room.positions.set(socket.id, { x: 3 + room.positions.size * 2, y: 4 });
    socket.emit("room:state", {
      code: room.code, name: room.name, members: [...room.members.values()],
      messages: room.messages.slice(-50), music: room.music,
      isHost: room.ownerId === socket.id,
      positions: [...room.positions.entries()].map(([id, pos]) => ({ id, nickname: room.members.get(id), ...pos }))
    });
    io.to(room.code).emit("room:members", [...room.members.values()]);
    io.to(room.code).emit("room:positions", [...room.positions.entries()].map(([id, pos]) => ({ id, nickname: room.members.get(id), ...pos })));
  });

  socket.on("chat:send", text => {
    const room = rooms.get(socket.data.room);
    if (!room) return;
    const message = { id: randomBytes(5).toString("hex"), nickname: socket.data.nickname, text: clean(text, 500), at: Date.now() };
    if (!message.text) return;
    room.messages.push(message); room.messages = room.messages.slice(-100);
    io.to(room.code).emit("chat:new", message);
  });

  socket.on("avatar:move", ({ x, y }) => {
    const room = rooms.get(socket.data.room);
    if (!room) return;
    const pos = { x: Math.max(0, Math.min(11, Number(x) || 0)), y: Math.max(0, Math.min(6, Number(y) || 0)) };
    room.positions.set(socket.id, pos);
    io.to(room.code).emit("room:positions", [...room.positions.entries()].map(([id, p]) => ({ id, nickname: room.members.get(id), ...p })));
  });

  socket.on("boxing:invite", invite => {
    const room = rooms.get(socket.data.room);
    if (!room || !invite?.to) return;
    io.to(room.code).emit("boxing:invite", { from: socket.data.nickname, to: clean(invite.to, 20), roomCode: room.code });
  });

  socket.on("boxing:start", payload => {
    const room = rooms.get(socket.data.room);
    if (!room || !Array.isArray(payload?.players) || payload.players.length !== 2) return;
    io.to(room.code).emit("boxing:start", { players: payload.players.map(n => clean(n, 20)), roomCode: room.code });
  });

  socket.on("boxing:action", action => {
    const room = rooms.get(socket.data.room);
    if (!room || !["hit", "guard"].includes(action?.type)) return;
    io.to(room.code).emit("boxing:action", { from: socket.data.nickname, type: action.type, power: Math.max(1, Math.min(20, Number(action.power) || 8)), active: Boolean(action.active) });
  });

  socket.on("music:update", update => {
    const room = rooms.get(socket.data.room);
    if (!room || room.ownerId !== socket.id) return socket.emit("music:error", "Chỉ chủ phòng mới có quyền điều khiển nhạc.");
    const url = clean(update?.url, 1000);
    // Accept direct audio URLs only in this MVP. Production should validate trusted hosts.
    if (url && !/^https:\/\/.+\.(mp3|ogg|wav|m4a)(\?.*)?$/i.test(url)) {
      return socket.emit("music:error", "Dùng đường dẫn HTTPS tới tệp âm thanh bạn có quyền sử dụng (MP3/OGG/WAV/M4A).");
    }
    room.music = { url, playing: Boolean(update?.playing), position: Math.max(0, Number(update?.position) || 0), updatedAt: Date.now() };
    io.to(room.code).emit("music:state", room.music);
  });

  socket.on("disconnect", () => {
    const code = socket.data.room, room = rooms.get(code);
    if (!room) return;
    room.members.delete(socket.id);
    room.positions.delete(socket.id);
    if (room.ownerId === socket.id) {
      room.ownerId = room.members.keys().next().value || null;
      if (room.ownerId) io.to(room.ownerId).emit("room:host", true);
    }
    io.to(code).emit("room:members", [...room.members.values()]);
    io.to(code).emit("room:positions", [...room.positions.entries()].map(([id, pos]) => ({ id, nickname: room.members.get(id), ...pos })));
  });
});

const port = process.env.PORT || 3001;
server.listen(port, () => console.log(`Private Hangout server running on :${port}`));
