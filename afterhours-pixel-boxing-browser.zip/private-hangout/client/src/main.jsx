import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { io } from "socket.io-client";
import { Users, Music2, MessageCircle, Gamepad2, LockKeyhole, Headphones, Sparkles, Send, Play, Pause, Plus, ArrowUpRight } from "lucide-react";
import "./style.css";
import BoxingGame from "./BoxingGame.jsx";

const API = import.meta.env.VITE_API_URL || "http://localhost:3001";
function App() {
  const [mode,setMode]=useState("home"), [nickname,setNickname]=useState(""); 
  const [roomName,setRoomName]=useState("Đêm tụ tập"), [password,setPassword]=useState(""), [code,setCode]=useState("");
  const [room,setRoom]=useState(null), [members,setMembers]=useState([]), [messages,setMessages]=useState([]);
  const [isHost,setIsHost]=useState(false), [positions,setPositions]=useState([]), [myPos,setMyPos]=useState({x:3,y:4});
  const [draft,setDraft]=useState(""), [musicUrl,setMusicUrl]=useState(""), [music,setMusic]=useState({url:"",playing:false,position:0});
  const [error,setError]=useState(""), [tab,setTab]=useState("chat"), [showBoxing,setShowBoxing]=useState(false);
  const socketRef=useRef(null), audioRef=useRef(null), endRef=useRef(null);

  async function enter(endpoint, payload) {
    setError("");
    try {
      const r=await fetch(`${API}${endpoint}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
      const data=await r.json(); if(!r.ok) throw new Error(data.error||"Không thể vào phòng.");
      setRoom(data); setCode(data.code); setMode("room");
    } catch(e){setError(e.message);}
  }
  useEffect(()=>{
    if(mode!=="room"||!room) return;
    const s=io(API); socketRef.current=s;
    s.on("connect",()=>s.emit("room:enter",{code:room.code,nickname:room.nickname}));
    s.on("room:state",v=>{setMembers(v.members);setMessages(v.messages);setMusic(v.music);setIsHost(v.isHost);setPositions(v.positions||[]);});
    s.on("room:positions",setPositions); s.on("room:host",setIsHost);
    s.on("room:members",setMembers); s.on("chat:new",m=>setMessages(old=>[...old,m].slice(-100)));
    s.on("music:state",setMusic); s.on("room:error",setError); s.on("music:error",setError);
    return ()=>s.disconnect();
  },[mode,room]);
  useEffect(()=>{endRef.current?.scrollIntoView({behavior:"smooth"});},[messages]);
  useEffect(()=>{
    const a=audioRef.current;if(!a||!music.url)return;
    if(Math.abs(a.currentTime-music.position)>2) a.currentTime=music.position;
    if(music.playing) a.play().catch(()=>{}); else a.pause();
  },[music]);
  function send(){if(!draft.trim())return;socketRef.current?.emit("chat:send",draft);setDraft("");}
  function updateMusic(playing){if(!isHost)return;const a=audioRef.current;socketRef.current?.emit("music:update",{url:musicUrl||music.url,playing,position:a?.currentTime||0});}
  function move(dx,dy){const next={x:Math.max(0,Math.min(11,myPos.x+dx)),y:Math.max(0,Math.min(6,myPos.y+dy))};setMyPos(next);socketRef.current?.emit("avatar:move",next);}
  function setTrack(){if(isHost)socketRef.current?.emit("music:update",{url:musicUrl,playing:false,position:0});}
  async function createRoom(e){e.preventDefault();await enter("/api/rooms",{name:roomName,password,nickname});}
  async function joinRoom(e){e.preventDefault();await enter(`/api/rooms/${code}/join`,{password,nickname});}
  const initials=(nickname||"B").slice(0,1).toUpperCase();

  if(mode==="home") return <main className="shell">
    <nav className="nav"><div className="brand"><span className="brandmark"><Sparkles size={18}/></span> afterhours<span className="dot">.</span></div><div className="navright"><span className="live"><i/> Không gian riêng tư</span><span className="avatar">{initials}</span></div></nav>
    <section className="hero"><div className="eyebrow"><span/> YOUR PRIVATE ONLINE LOUNGE</div><h1>Một nơi để<br/><em>ở cùng nhau.</em></h1><p>Tạo một căn phòng riêng, mời hội bạn vào trò chuyện, nghe nhạc và chơi những trò vui — dù mỗi người ở một nơi.</p>
      <div className="hero-actions"><a href="#rooms" className="primary">Khám phá phòng <ArrowUpRight size={17}/></a><span className="subtle">Không gian của riêng nhóm bạn</span></div>
      <div className="orb orb1"/><div className="orb orb2"/>
    </section>
    <section id="rooms" className="section"><div className="sectionhead"><div><div className="eyebrow">CHỌN ĐIỂM HẸN</div><h2>Hôm nay, mình làm gì?</h2></div><span className="sectionnote">01 / PRIVATE SPACES</span></div>
      <div className="cards">
        <article className="tile tile-create"><div className="tileicon"><Users/></div><div className="tilemeta">01 — YOUR SPACE</div><h3>Tạo phòng riêng</h3><p>Đặt tên, tạo mật khẩu và gửi mã phòng cho bạn bè.</p><button className="tilelink" onClick={()=>setMode("create")}>Tạo không gian <ArrowUpRight size={16}/></button></article>
        <article className="tile tile-join"><div className="tileicon"><LockKeyhole/></div><div className="tilemeta">02 — COME TOGETHER</div><h3>Vào phòng bạn bè</h3><p>Nhập mã phòng và mật khẩu để tham gia cuộc vui.</p><button className="tilelink" onClick={()=>setMode("join")}>Tham gia phòng <ArrowUpRight size={16}/></button></article>
        <article className="tile tile-music"><div className="tileicon"><Headphones/></div><div className="tilemeta">03 — LISTEN TOGETHER</div><h3>Listening lounge</h3><p>Đồng bộ nhạc trong phòng và tận hưởng cùng nhau.</p><button className="tilelink" onClick={()=>setMode("create")}>Mở phòng nghe nhạc <ArrowUpRight size={16}/></button></article>
      </div>
    </section>
    <footer><div className="brand">afterhours<span className="dot">.</span></div><span>Made for the little moments together.</span></footer>
    {mode!=="home" && <div className="modalback"><form className="modal" onSubmit={mode==="create"?createRoom:joinRoom}><button type="button" className="close" onClick={()=>setMode("home")}>×</button><div className="eyebrow">{mode==="create"?"START A NEW SPACE":"JOIN YOUR FRIENDS"}</div><h2>{mode==="create"?"Tạo phòng mới":"Tham gia phòng"}</h2>
      <label>Tên hiển thị<input value={nickname} onChange={e=>setNickname(e.target.value)} placeholder="Tên của bạn" required maxLength="20"/></label>
      {mode==="create"&&<label>Tên phòng<input value={roomName} onChange={e=>setRoomName(e.target.value)} required maxLength="24"/></label>}
      {mode==="join"&&<label>Mã phòng<input value={code} onChange={e=>setCode(e.target.value.toUpperCase())} placeholder="VD: A1B2C3" required maxLength="8"/></label>}
      <label>Mật khẩu phòng<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Ít nhất 4 ký tự" required minLength="4"/></label>
      {error&&<p className="error">{error}</p>}<button className="primary full" type="submit">{mode==="create"?"Tạo phòng":"Vào phòng"} <ArrowUpRight size={17}/></button></form></div>}
  </main>;

  return <main className="room-shell"><nav className="nav"><div className="brand" onClick={()=>{setMode("home");setRoom(null)}}>← <span className="brandtext">afterhours<span className="dot">.</span></span></div><div className="navright"><span className="live"><i/> Phòng đang hoạt động</span><button className="exit" onClick={()=>{socketRef.current?.disconnect();setRoom(null);setMode("home")}}>Rời phòng</button></div></nav>
    <div className="roomtop"><div><div className="eyebrow">PIXEL HANGOUT / {room?.code}</div><h1>{room?.name}</h1><p>Di chuyển avatar và gặp nhau trong căn phòng nhỏ.</p></div><div className="room-actions"><button className="arcade-launch" onClick={()=>setShowBoxing(v=>!v)}><Gamepad2 size={16}/> {showBoxing?"Quay lại lounge":"Chơi Pixel Boxing"}</button><div className="memberstack">{members.map((m,i)=><span className="avatar" title={m} key={i}>{m.slice(0,1).toUpperCase()}</span>)}<span className="membercount"><Users size={14}/> {members.length} online</span></div></div></div>
    {showBoxing?<BoxingGame socket={socketRef.current} members={members} nickname={room?.nickname||nickname} roomCode={room?.code} onBack={()=>setShowBoxing(false)}/>:<div className="pixel-layout">
      <section className="pixel-stage-wrap">
        <div className="stage-top"><span><i/> LIVE ROOM</span><span>WASD / PHÍM MŨI TÊN ĐỂ DI CHUYỂN</span></div>
        <div className="pixel-stage">
          <div className="window-pixel"><span>✦ ✧ ✦</span></div>
          <div className="wall-sign">AFTERHOURS<br/><small>GOOD TIMES CLUB</small></div>
          <div className="plant plant-left">🌿</div><div className="plant plant-right">🌱</div>
          <div className="rug"/>
          <div className="sofa"><span>▰ ▰ ▰</span></div>
          <div className="coffee-table"><span>♪</span></div>
          <div className="speaker speaker-left">♫</div><div className="speaker speaker-right">♫</div>
          {positions.map((p,i)=><div className="pixel-player" key={p.id} style={{left:`${5+p.x*7.45}%`,top:`${17+p.y*9.2}%`}}>
            <div className={`sprite ${p.id===socketRef.current?.id?"mine":""}`}><span className="hair"/><span className="face"/><span className="body"/></div><label>{p.nickname}{p.id===socketRef.current?.id?" (bạn)":""}</label>
          </div>)}
          <div className="stage-caption">A SMALL PLACE FOR YOUR PEOPLE</div>
        </div>
        <div className="movement"><span>MOVE</span><button onClick={()=>move(0,-1)}>↑</button><div><button onClick={()=>move(-1,0)}>←</button><button onClick={()=>move(0,1)}>↓</button><button onClick={()=>move(1,0)}>→</button></div></div>
      </section>
      <aside className="pixel-side">
        <section className="sidepanel"><div className="sidehead"><div><div className="eyebrow">THE CREW</div><h3>Đang ở đây</h3></div><span className="count">{members.length}</span></div>{members.map((m,i)=><div className="person" key={i}><span className="avatar">{m.slice(0,1).toUpperCase()}</span><span>{m}</span><i/></div>)}</section>
        <section className="sidepanel chat-panel"><div className="sidehead"><div><div className="eyebrow">ROOM CHAT</div><h3>Trò chuyện</h3></div><MessageCircle size={17}/></div><div className="chatlog compact">{messages.map(m=><div className="message" key={m.id}><span className="avatar small">{m.nickname.slice(0,1).toUpperCase()}</span><div><b>{m.nickname}</b><p>{m.text}</p></div></div>)}{messages.length===0&&<div className="empty">Mở lời chào đầu tiên nhé ✨</div>}<div ref={endRef}/></div><div className="composer"><input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Nhắn cho mọi người..."/><button onClick={send}><Send size={16}/></button></div></section>
        <section className="sidepanel music-panel"><div className="sidehead"><div><div className="eyebrow">SHARED LISTENING</div><h3>Nhạc phòng</h3></div><Music2 size={17}/></div>
          {isHost?<><input className="music-input" value={musicUrl} onChange={e=>setMusicUrl(e.target.value)} placeholder="Link file nhạc HTTPS..."/><button className="music-action" onClick={setTrack}>Cập nhật bài nhạc</button><div className="host-note">Bạn là chủ phòng · Bạn điều khiển nhạc cho mọi người.</div></>:<div className="host-note">Chủ phòng đang điều khiển nhạc. Bạn có thể nghe cùng mọi người.</div>}
          <div className="track"><span className="mini-vinyl">♫</span><span className="trackname">{music.url?music.url.split("/").pop():"Chưa có bài nhạc"}</span>{isHost&&music.url&&<button onClick={()=>updateMusic(!music.playing)}>{music.playing?<Pause size={16}/>:<Play size={16}/>}</button>}</div>
          <audio ref={audioRef} src={music.url||undefined} onEnded={()=>{if(isHost)updateMusic(false)}} controls className="audio"/>
        </section>
      </aside>
    </div>}
    <footer><div className="brand">afterhours<span className="dot">.</span></div><span>Keep the good company close.</span></footer>
  </main>;
}
createRoot(document.getElementById("root")).render(<App/>);
