# Afterhours — Private Hangout + Pixel Boxing (MVP)

A responsive browser-based private lounge for friends, with a 2D pixel room and an arcade boxing mini-game. No app installation is required.

## Included
- Create a password-protected room and share its room code
- Join a room with code + password
- Realtime member list, chat and avatar movement
- Shared listening controlled by the room host (direct HTTPS MP3/OGG/WAV/M4A files)
- **Pixel Boxing:** play against CPU (easy / medium / hard) or invite someone in the same room
- Keyboard controls: `J` quick punch, `K` strong punch, hold `L` to block; on mobile, use the on-screen controls
- Responsive layout for desktop and mobile browsers

## Run locally
Requirements: Node.js 20+

```bash
npm run install:all
npm run dev
```

Open the Vite URL shown in the terminal (usually http://localhost:5173). The Socket.IO server runs on http://localhost:3001.

For deployment, set `VITE_API_URL` in the client environment to the public server URL, and set `CLIENT_ORIGIN` on the server to the deployed client origin.

## MVP limitations before public launch
- Rooms and live game events are held in server memory; restarting the server clears rooms.
- The friend match is a lightweight room-based prototype, not a competitive game server with authoritative simulation, matchmaking, anti-cheat, or latency compensation.
- Passwords are hashed with bcryptjs, but production still needs stronger authentication, persistent storage, rate limits, abuse controls, invite expiry, HTTPS, and input validation.
- Shared music accepts direct audio file URLs only. Use audio you own or have permission to stream.
